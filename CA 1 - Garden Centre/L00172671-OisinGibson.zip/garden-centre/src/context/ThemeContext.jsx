// Theme Context for Dark Mode functionality
// L00172671
// Oisin Gibson
// 
// REFERENCES
// Dark Mode Implementation: https://www.w3schools.com/howto/howto_js_toggle_dark_mode.asp
// React Context: https://react.dev/reference/react/createContext
// LocalStorage API: https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage
// CSS Classes: https://developer.mozilla.org/en-US/docs/Web/API/Element/classList

import React, { createContext, useContext, useState, useEffect } from 'react';

// Create a React Context for theme management
// Context allows components to share state without prop drilling
// Reference: https://react.dev/learn/passing-data-deeply-with-context
const ThemeContext = createContext();

/**
 * Custom hook to access theme context
 * This hook provides a clean way for components to access theme state and functions
 * 
 * @returns {Object} Theme context value containing isDarkMode, toggleTheme, and theme
 * @throws {Error} If used outside of ThemeProvider
 * 
 * Usage example:
 * const { isDarkMode, toggleTheme } = useTheme();
 */
export const useTheme = () => {// Arrow function to define useTheme hook
  // Get the current context value
  const context = useContext(ThemeContext);
  
  // Guard clause: Ensure hook is used within provider
  // This prevents runtime errors if hook is used incorrectly
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  
  return context;
};

/**
 * ThemeProvider Component
 * Provides theme state and functionality to all child components
 * Handles theme persistence using localStorage and DOM manipulation
 * 
 * @param {Object} props - Component props
 * @param {React.ReactNode} props.children - Child components to wrap with theme context
 * 
 * Features:
 * - Persistent theme selection (survives page refresh)
 * - Automatic DOM class manipulation for CSS styling
 * - Toggle functionality between light and dark modes
 * - localStorage integration for user preference storage
 */
export const ThemeProvider = ({ children }) => {
  // Initialize theme state from localStorage or default to light mode
  // Using lazy initial state to avoid localStorage access on every render
  // Reference: https://react.dev/reference/react/useState#avoiding-recreating-the-initial-state
  const [isDarkMode, setIsDarkMode] = useState(() => {
    // Try to get saved theme preference from browser storage
    const savedTheme = localStorage.getItem('garden-centre-theme');
    
    // Return true if saved theme is 'dark', false otherwise (defaults to light mode)
    // This ensures the app remembers user's theme choice across sessions
    return savedTheme === 'dark';
  });

  /**
   * Toggle between light and dark mode
   * Uses functional state update to ensure we get the current state value
   * 
   * Reference: https://react.dev/reference/react/useState#updating-state-based-on-the-previous-state
   */
  const toggleTheme = () => {// Arrow function to define toggleTheme
    // Use functional update to toggle boolean value
    // prev => !prev ensures we always get the opposite of current state
    setIsDarkMode(prev => !prev);
  };

  /**
   * Side effect to handle theme persistence and DOM manipulation
   * Runs whenever isDarkMode state changes
   * 
   * Reference: https://react.dev/reference/react/useEffect
   */
  useEffect(() => {// Arrow function to define effect
    // Save current theme preference to localStorage
    // This allows the theme choice to persist across browser sessions
    // Key: 'garden-centre-theme', Value: 'dark' or 'light'
    localStorage.setItem('garden-centre-theme', isDarkMode ? 'dark' : 'light');
    
    // Manipulate DOM to add/remove dark-mode class on document body
    // This approach follows the W3Schools dark mode implementation pattern
    // The CSS uses body.dark-mode selector to apply dark theme styles
    if (isDarkMode) {
      // Add 'dark-mode' class to body element
      // This triggers all CSS rules that target .dark-mode
      document.body.classList.add('dark-mode');
    } else {
      // Remove 'dark-mode' class from body element
      // This reverts to default (light mode) CSS styles
      document.body.classList.remove('dark-mode');
    }
  }, [isDarkMode]); // Dependency array: effect runs when isDarkMode changes

  /**
   * Context value object
   * Contains all theme-related state and functions that child components can access
   * 
   * Properties:
   * - isDarkMode: Boolean indicating current theme state
   * - toggleTheme: Function to switch between light and dark mode
   * - theme: String representation of current theme ('dark' or 'light')
   */
  const value = {
    isDarkMode,        // Current theme state (boolean)
    toggleTheme,       // Function to toggle theme
    theme: isDarkMode ? 'dark' : 'light'  // String representation 
  };

  /**
   * Provide theme context to all child components
   * 
   * The Provider component makes the theme value available to all descendants
   * Any component wrapped by ThemeProvider can use the useTheme() hook
   * to access theme state and functions
   * 
   * Reference: https://react.dev/reference/react/createContext#provider
   */
  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
};
