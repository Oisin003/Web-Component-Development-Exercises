// Currency Context for Currency Selection functionality
// L00172671
// Oisin Gibson
// 
// REFERENCES 
// Currency conversion: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/NumberFormat

import React, { createContext, useContext, useState, useEffect } from 'react';

const CurrencyContext = createContext();

export const useCurrency = () => {// Custom hook to access currency context
  const context = useContext(CurrencyContext);
  if (!context) {// Guard clause: Ensure hook is used within provider
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
};

// Currency data with exchange rates
const currencies = {
  EUR: { symbol: '€', name: 'Euro', rate: 1 }, // Base currency
  USD: { symbol: '$', name: 'US Dollar', rate: 1.09 },
  GBP: { symbol: '£', name: 'British Pound', rate: 0.86 },
  CAD: { symbol: 'C$', name: 'Canadian Dollar', rate: 1.48 },
  AUD: { symbol: 'A$', name: 'Australian Dollar', rate: 1.66 },
  JPY: { symbol: '¥', name: 'Japanese Yen', rate: 163.2 },
  CHF: { symbol: 'CHF', name: 'Swiss Franc', rate: 0.96 },
  SEK: { symbol: 'kr', name: 'Swedish Krona', rate: 11.34 },
  NOK: { symbol: 'kr', name: 'Norwegian Krone', rate: 11.87 },
  DKK: { symbol: 'kr', name: 'Danish Krone', rate: 7.46 }
};

export const CurrencyProvider = ({ children }) => {// Arrow function to define CurrencyProvider component
  // Initialize currency from localStorage or default to EUR
  const [selectedCurrency, setSelectedCurrency] = useState(() => {
    const savedCurrency = localStorage.getItem('garden-centre-currency');
    return savedCurrency || 'EUR';
  });

  // Save currency preference to localStorage
  useEffect(() => {// Whenever selectedCurrency changes, update localStorage
    localStorage.setItem('garden-centre-currency', selectedCurrency);
  }, [selectedCurrency]);

  // Function to convert price from EUR to selected currency
  const convertPrice = (priceInEur) => {// Convert price based on selected currency rate
    // Get exchange rate for selected currency ? = optional chaining 
    const rate = currencies[selectedCurrency]?.rate || 1;
    return priceInEur * rate;// Return converted price
  };

  // Function to format price with currency symbol
  const formatPrice = (priceInEur) => {// Format price for display
    const convertedPrice = convertPrice(priceInEur);
    const currency = currencies[selectedCurrency];
    
    // Format number based on currency
    if (selectedCurrency === 'JPY') {
      // Japanese Yen doesn't use decimal places
      return `${currency.symbol}${Math.round(convertedPrice)}`;
    } else {
      return `${currency.symbol}${convertedPrice.toFixed(2)}`;
    }
  };

  // Function to change currency
  const changeCurrency = (currencyCode) => {// Arrow function to change selected currency
    if (currencies[currencyCode]) {
      setSelectedCurrency(currencyCode);
    }
  };

  const value = { // Context value to be provided to consumers
    selectedCurrency,
    currencies,
    convertPrice,
    formatPrice,
    changeCurrency,
    currentCurrency: currencies[selectedCurrency] // Current currency details
  };

  return (// Provide context to children components
    <CurrencyContext.Provider value={value}>
        {/* // Render child components */}
      {children}
    </CurrencyContext.Provider>
  );
};
