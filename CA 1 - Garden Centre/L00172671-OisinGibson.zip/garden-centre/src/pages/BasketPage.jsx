// src/pages/BasketPage.jsx

/* 
 * REFERENCES
 * JavaScript Array Methods:
 * - Array.reduce(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/reduce
 * - Array.length: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/length
 * 
 * Conditional Rendering:
 * - Conditional Rendering: https://react.dev/learn/conditional-rendering
 * - Ternary Operator: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Conditional_Operator
 * 
 * React Router Navigation:
 * - Link Component: https://reactrouter.com/en/main/components/link
 * - Navigation Patterns: https://reactrouter.com/en/main/guides/navigation
 * 
 * CSS Animation & Styling:
 * - CSS Animations: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Animations/Using_CSS_animations
 */

import { useBasket } from "../context/BasketContext";
import { useCurrency } from "../context/CurrencyContext";
import { Link } from "react-router-dom";
import "../ProductCard.css"

const BasketPage = () => {// Arrow fuction to define the BasketPage component
    // Destructure basketItems and removeFromBasket from useBasket context
    const { basketItems, removeFromBasket } = useBasket();// Hook to access basket context
    // Access currency formatting functions
    const { formatPrice, convertPrice } = useCurrency();
    
    // Function to handle item removal from basket
    const handleRemoveItem = (item) => {// Arrow function to handle removing an item
        removeFromBasket(item);
    };

    // .reduce() takes the array of basketItems and sums up their prices (0 is the inital value)
    // Calculate total in EUR first, then format with currency conversion
    let totalInEur = basketItems.reduce((sum, item) => sum + item.price, 0);

    return (
        <section className="basket-page">
            <div className="basket-header">
                <h2>
                    <i className="fas fa-shopping-basket"></i>
                    Shopping Basket
                </h2>
            </div>

            {basketItems.length === 0 ? (// If basket is empty, show empty basket message
                <div className="empty-basket">
                    <div className="empty-basket-content">
                        <div className="empty-basket-icon">
                            <i className="fas fa-shopping-basket"></i>
                            <div className="icon-decoration">
                                <i className="fas fa-seedling"></i>
                                <i className="fas fa-leaf"></i>
                                <i className="fas fa-flower"></i>
                            </div>
                        </div>
                        <h3>Your Garden Basket is Empty</h3>
                        <p>Start your gardening journey by adding some beautiful plants, tools, or garden care products to your basket!</p>
                        <div className="empty-basket-actions">
                            <Link to="/plants" className="shop-button primary">
                                <i className="fas fa-seedling"></i>
                                Shop Plants
                            </Link>
                            <Link to="/tools" className="shop-button secondary">
                                <i className="fas fa-tools"></i>
                                Browse Tools
                            </Link>
                            <Link to="/garden-care" className="shop-button secondary">
                                <i className="fas fa-spray-can"></i>
                                Garden Care
                            </Link>
                        </div>
                        <div className="empty-basket-features">
                            <div className="feature">
                                <i className="fas fa-shipping-fast"></i>
                                <span>Fast Delivery</span>
                            </div>
                            <div className="feature">
                                <i className="fas fa-leaf"></i>
                                <span>Eco-Friendly</span>
                            </div>
                            <div className="feature">
                                <i className="fas fa-award"></i>
                                <span>Quality Guaranteed</span>
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
                <>
                    <div className="basket-items">
                        {basketItems.map((item, index) => (
                            <div key={index} className="basket-item">
                                <img
                                    src={item.images?.[0] || item.image || "/images/placeholder.png"}
                                    alt={item.name || "Product"}
                                    className="basket-image"
                                    onError={(e) => {
                                        console.warn("Basket image failed:", e.currentTarget.src);
                                        e.currentTarget.onerror = null;
                                        e.currentTarget.src = "/images/placeholder.png";
                                    }}
                                />
                                <div className="item-details">
                                    <h3>{item.name}</h3>
                                    {/* Display the price with currency conversion */}
                                    <p>{formatPrice(item.price)}</p>
                                    {/* Use the handleRemoveItem function to remove item */}
                                    <button
                                        onClick={() => handleRemoveItem(item)}
                                        className="remove-button"
                                    >
                                        <i className="fas fa-trash-alt"></i>
                                        Remove from Basket
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                    {/* Display the total price with currency conversion */}
                    <div className="basket-summary">
                        <h3 className="total">
                            <i className="fas fa-calculator"></i>
                            Total: {formatPrice(totalInEur)}
                        </h3>
                        <Link to="/checkout" className="nav-btn checkout-btn">
                            <i className="fas fa-credit-card"></i>
                            Proceed to Checkout
                        </Link>
                    </div>
                </>
            )}
        </section>
    );
};

export default BasketPage;
