// Oisin Gibson
// L00172671

// src/pages/Home.jsx
// Main home page component that displays welcome message, search functionality, 
// gardening tips, newsletter signup, and about section

/* 
 * REFERENCES & DOCUMENTATION:
 * 
 * React Core Concepts:
 * - React Components: https://react.dev/learn/your-first-component
 * - useState Hook: https://react.dev/reference/react/useState
 * - useEffect Hook: https://react.dev/reference/react/useEffect
 * - useContext Hook: https://react.dev/reference/react/usecontext
 * - Conditional Rendering: https://react.dev/learn/conditional-rendering
 * 
 * Array Methods & Data Manipulation:
 * - Array.filter(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter
 * - Array.map(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map
 * - Object.values(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/values
 * 
 * Bootstrap Icons:
 * - Bootstrap Icons: https://icons.getbootstrap.com/
 * - SVG Usage Guide: https://developer.mozilla.org/en-US/docs/Web/SVG/Tutorial/Getting_Started
 * 
 * Form Handling:
 * - Controlled Components: https://react.dev/reference/react-dom/components/input#controlling-an-input-with-a-state-variable
 * - Form Events: https://react.dev/reference/react-dom/components/form
 */

import React, { useState, useEffect, useContext } from "react";
import '../Home.css';
import { products } from "../data/stock";
import { getFeaturedItems } from "../utils/getFeaturedItems";
import { SearchContext } from "../context/SearchContext"; // added
import ProductCard from "../components/ProductCard"; // added
import FeaturedItemOfWeek from "../components/FeaturedItemOfWeek"; // added

function Home() {
  // Access search query state from SearchContext for global search functionality
  const { query, setQuery } = useContext(SearchContext); // added

  // UseHook - Declare state showEmailCard - set it to false to hide it - setShowEmailCard updates it
  let [showEmailCard, setShowEmailCard] = useState(false);
  //UseSate Hook - creates local component state for featured items - empty array
  let [featuredItems, setFeaturedItems] = useState([]);

  //useEffect Hook - runs once when component mounts - selects featured items from stock data
  useEffect(() => {
    // Calls function - passes it into projects 
    const selected = getFeaturedItems(products);
    //updates local sate with the selected products
    setFeaturedItems(selected);
  }, []);// dependency array is empty - runs only once on mount

  // prepare search results (null when no query)
  // Convert query to lowercase and trim whitespace for consistent searching
  const q = (query || "").trim().toLowerCase();
  // Flatten the products object into a single array for easier searching
  const allProducts = Object.values(products).flat();
  // Filter products by name if there's a search query, otherwise return null
  const searchResults = q ? allProducts.filter(p => p.name.toLowerCase().includes(q)) : null;

  return (
    <main>
      {/* Welcome Message - Main heading for the home page */}
      <h2 className="welcome">Welcome to the Garden Centre</h2>

      {/* Central Search Bar — now wired to SearchContext */}
      {/* Controlled input that updates global search state */}
      <input
        type="text"
        placeholder="Search plants, tools, care..."
        className="search-bar"
        value={query || ""} // Display current search query or empty string
        onChange={(e) => setQuery(e.target.value)} // Update search query on input change
      />

      {/* Featured Item of the Week */}
      <FeaturedItemOfWeek />

      {/* Featured Products OR Search Results */}
      {/* Conditional rendering: show search results if there's a query, otherwise show gardening tips */}
      <div className="featured-products">
        {q ? (
          // Search Results Section - Display when user has entered a search query
          <>
            <h3>Search results for "{query}"</h3>
            <div className="product-cards">
              {searchResults.length > 0 ? (
                // Map through search results and render ProductCard for each item
                searchResults.map(item => (
                  <ProductCard key={item.id} item={item} />
                ))
              ) : (
                // Show "out of stock" message if no results found
                <ProductCard placeholderMessage={`Sorry, "${query}" is out of stock`} />
              )}
            </div>
          </>
        ) : (
          // Default Content Section - Gardening Tips (shown when no search query)
          <>
            {/* Gardening Tips Section */}
            {/* Main heading with Bootstrap icon for visual appeal */}
            <h3>
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" className="bi bi-flower1" viewBox="0 0 16 16" style={{marginRight: '8px', color: '#4CAF50'}}>
                <path d="M6.174 1.184a2 2 0 0 1 3.652 0A2 2 0 0 1 12.99 3.01a2 2 0 0 1 1.826 3.164 2 2 0 0 1 0 3.652 2 2 0 0 1-1.826 3.164 2 2 0 0 1-3.164 1.826 2 2 0 0 1-3.652 0A2 2 0 0 1 3.01 12.99a2 2 0 0 1-1.826-3.164 2 2 0 0 1 0-3.652A2 2 0 0 1 3.01 3.01a2 2 0 0 1 3.164-1.826M8 2.5a.5.5 0 0 0-.5.5v2a.5.5 0 0 0 1 0v-2a.5.5 0 0 0-.5-.5M5.5 5a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1zM3 8a.5.5 0 0 0 .5.5h2a.5.5 0 0 0 0-1h-2A.5.5 0 0 0 3 8m.5 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1zm3 1.5a.5.5 0 0 0 .5.5v2a.5.5 0 0 0 1 0v-2a.5.5 0 0 0-.5-.5m3-1.5a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1zm1.5-2.5a.5.5 0 0 0-.5-.5h-2a.5.5 0 0 0 0 1h2a.5.5 0 0 0 .5-.5M8.5 5a.5.5 0 0 0-.5-.5v-2a.5.5 0 0 0-1 0v2a.5.5 0 0 0 .5.5"/>
              </svg>
              Seasonal Gardening Tips
            </h3>
            {/* Subheading to explain the section's purpose */}
            <p>Expert advice to help your garden thrive this season</p>
            {/* Grid container for gardening tips cards */}
            <div className="product-cards tips-grid">
              {/* Autumn Planting Tip Card */}
              <div className="tip-card">
                <div className="tip-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" className="bi bi-flower2" viewBox="0 0 16 16">
                    <path d="M8 16a4 4 0 0 0 4-4 4 4 0 0 0 0-8 4 4 0 0 0-8 0 4 4 0 0 0 0 8 4 4 0 0 0 4 4M8 1a3 3 0 0 1 0 6 3 3 0 0 1 0-6M1 8a3 3 0 0 1 6 0 3 3 0 0 1-6 0m6 0a3 3 0 0 1 6 0 3 3 0 0 1-6 0"/>
                  </svg>
                </div>
                <h4>Autumn Planting</h4>
                <p>October is perfect for planting spring bulbs like tulips and daffodils. Plant them 6 inches deep for best results.</p>
                <div className="tip-badge">Fall Tip</div>
              </div>

              {/* Winter Watering Tip Card */}
              <div className="tip-card">
                <div className="tip-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" className="bi bi-droplet" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M7.21.8C7.69.295 8 0 8 0q.164.544.371 1.038c.812 1.946 2.073 3.35 3.197 4.6C12.878 7.096 14 8.345 14 10a6 6 0 0 1-12 0C2 6.668 5.58 2.517 7.21.8m.413 1.021A31 31 0 0 0 5.794 3.99c-.726.95-1.436 2.008-1.96 3.07C3.304 8.133 3 9.138 3 10a5 5 0 0 0 10 0c0-1.201-.796-2.157-2.181-3.7l-.03-.032C9.75 5.11 8.5 3.72 7.623 1.82z"/>
                    <path fill-rule="evenodd" d="M4.553 7.776c.82-1.641 1.717-2.753 2.093-3.13l.708.708c-.29.29-1.128 1.311-1.907 2.87z"/>
                  </svg>
                </div>
                <h4>Winter Watering</h4>
                <p>Reduce watering frequency as plants enter dormancy. Water deeply but less often to prevent root rot.</p>
                <div className="tip-badge">Winter Care</div>
              </div>

              {/* Mulching Benefits Tip Card */}
              <div className="tip-card">
                <div className="tip-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" className="bi bi-tree" viewBox="0 0 16 16">
                    <path d="M8.416.223a.5.5 0 0 0-.832 0l-3 4.5A.5.5 0 0 0 5 5.5h.098L3.076 8.735A.5.5 0 0 0 3.5 9.5h.191l-1.638 3.276a.5.5 0 0 0 .447.724H7V16h2v-2.5h4.5a.5.5 0 0 0 .447-.724L12.31 9.5h.191a.5.5 0 0 0 .424-.765L10.902 5.5H11a.5.5 0 0 0 .416-.777zM6.437 4.758A.5.5 0 0 0 6 4.5h-.066L8 1.401 10.066 4.5H10a.5.5 0 0 0-.424.765L11.598 8.5H11.5a.5.5 0 0 0-.447.724L12.69 12.5H3.309l1.638-3.276A.5.5 0 0 0 4.5 8.5h-.098l2.022-3.235a.5.5 0 0 0 .013-.507"/>
                  </svg>
                </div>
                <h4>Mulching Benefits</h4>
                <p>Apply a 2-3 inch layer of mulch around plants to retain moisture and suppress weeds through winter.</p>
                <div className="tip-badge">Year-Round</div>
              </div>

              {/* Pruning Season Tip Card */}
              <div className="tip-card">
                <div className="tip-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" className="bi bi-scissors" viewBox="0 0 16 16">
                    <path d="M3.5 3.5c-.614-.884-.074-1.962.858-2.5L8 7.226 11.642 1c.932.538 1.472 1.616.858 2.5L8.81 8.61l1.556 2.661a2.5 2.5 0 1 1-.794.637L8 9.73l-1.572 2.177a2.5 2.5 0 1 1-.794-.637L7.19 8.61zm2.5 10a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0m7 0a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0"/>
                  </svg>
                </div>
                <h4>Pruning Season</h4>
                <p>Late autumn is ideal for pruning dormant trees and shrubs. Remove dead, damaged, or crossing branches.</p>
                <div className="tip-badge">Maintenance</div>
              </div>

              {/* Frost Protection Tip Card */}
              <div className="tip-card">
                <div className="tip-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" className="bi bi-snow" viewBox="0 0 16 16">
                    <path d="M8 16a.5.5 0 0 1-.5-.5v-1.293l-.646.647a.5.5 0 0 1-.707-.708L7.5 12.793V8.866l-3.4 1.963-.496 1.85a.5.5 0 1 1-.966-.26l.237-.882-1.12.646a.5.5 0 0 1-.5-.866l1.12-.646-.884-.237a.5.5 0 1 1 .26-.966l1.848.495L7 8 3.6 6.037l-1.85.495a.5.5 0 0 1-.258-.966l.883-.237-1.12-.646a.5.5 0 1 1 .5-.866l1.12.646-.237-.883a.5.5 0 1 1 .966-.258l.495 1.849L7.5 7.134V3.207L6.147 1.854a.5.5 0 1 1 .707-.708l.646.647V.5a.5.5 0 1 1 1 0v1.293l.647-.647a.5.5 0 1 1 .707.708L8.5 3.207v3.927l3.4-1.963.496-1.85a.5.5 0 1 1 .966.26l-.236.882 1.12-.646a.5.5 0 0 1 .5.866l-1.12.646.883.237a.5.5 0 1 1-.26.966l-1.848-.495L9 8l3.4 1.963 1.849-.495a.5.5 0 0 1 .259.966l-.883.237 1.12.646a.5.5 0 0 1-.5.866l-1.12-.646.236.883a.5.5 0 1 1-.966.258l-.495-1.849-3.4-1.963v3.927l1.353 1.353a.5.5 0 0 1-.707.708l-.647-.647V15.5a.5.5 0 0 1-.5.5"/>
                  </svg>
                </div>
                <h4>Frost Protection</h4>
                <p>Cover tender plants with burlap or frost cloth when temperatures drop below freezing.</p>
                <div className="tip-badge">Protection</div>
              </div>

              {/* Tool Maintenance Tip Card */}
              <div className="tip-card">
                <div className="tip-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" className="bi bi-tools" viewBox="0 0 16 16">
                    <path d="M1 0 0 1l2.2 3.081a1 1 0 0 0 .815.419h.07a1 1 0 0 1 .708.293L2.5 6.086l.71.71L5.5 4.5a1 1 0 0 1 .293-.708L6.5 3.086A1 1 0 0 0 6.919 2.2L10 0l-1-1-3.081 2.2a1 1 0 0 0-.419.815v.07a1 1 0 0 1-.293.708L3.914 4.086l-.71-.71L5.5 1.5a1 1 0 0 1 .708-.293h.07a1 1 0 0 0 .815-.419L10 0 9 1 6.5 3.5a1 1 0 0 1-.708.293h-.07a1 1 0 0 0-.815.419L2.5 6.5l.71.71L6.5 4.914A1 1 0 0 1 7.207 4.5h.07a1 1 0 0 0 .815-.419L11 1l-1-1-3.081 2.2a1 1 0 0 0-.419.815v.07a1 1 0 0 1-.293.708L4.914 5.086l-.71-.71L6.5 2.086a1 1 0 0 1 .708-.293h.07a1 1 0 0 0 .815-.419L11 0l1 1-2.2 3.081a1 1 0 0 0-.419.815v.07a1 1 0 0 1-.293.708L7.793 6.207l-.71-.71L9.5 3.086a1 1 0 0 1 .708-.293h.07a1 1 0 0 0 .815-.419L14 0l1 1-3.081 2.2a1 1 0 0 0-.419.815v.07a1 1 0 0 1-.293.708L9.914 6.086l-.71-.71L11.5 3.086a1 1 0 0 1 .708-.293h.07a1 1 0 0 0 .815-.419L16 0v16l-1-1-3.081-2.2a1 1 0 0 0-.815-.419h-.07a1 1 0 0 1-.708-.293L9.914 10.914l.71-.71L12.5 12.5a1 1 0 0 1 .293.708v.07a1 1 0 0 0 .419.815L16 16l-1 1-2.2-3.081a1 1 0 0 0-.815-.419h-.07a1 1 0 0 1-.708-.293L9.914 11.914l.71-.71L12.5 13.5a1 1 0 0 1 .293.708v.07a1 1 0 0 0 .419.815L16 16"/>
                  </svg>
                </div>
                <h4>Tool Maintenance</h4>
                <p>Clean and oil your garden tools before winter storage. Sharp, clean tools make spring work easier.</p>
                <div className="tip-badge">Preparation</div>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Newsletter Prompt */}
      {/* Section to encourage newsletter subscription */}
      {/* <div className="newsletter-prompt">
        <p>Stay updated with seasonal tips and offers!</p>
        <button
          className="sub_button"
          // Arrow notation used to define the onClick event handler function - True means show
          onClick={() => setShowEmailCard(true)}
        >
          Subscribe
        </button>
      </div> */}

      {/* Email Card: Conditionally rendered when showEmailCard is true */}
      {/* Newsletter subscription modal/card */}
      {showEmailCard && ( // Checks if the Card is true or false - if true show the card
        <div className="email-card">
          {/* Card Header */}
          <h5>Subscribe to our newsletter</h5>
          <p>Enter your email to receive updates:</p>

          {/* Email Form */}
          <form className="email-form">
            {/* Email Input Field */}
            <input
              type="email"
              placeholder="Email address"
              className="form-control"
            />

            {/* Submit Button*/}
            <button type="submit" className="sub_button">
              Submit
            </button>

            {/* Cancel Button: closes the email subscription card */}
            <button
              type="button"
              className="sub_button" // Bootstrap styling: grey button with top margin
              onClick={() => setShowEmailCard(false)} // React event handler: hides the email card by updating state - arrow notation used
            >
              Cancel
            </button>

          </form>
        </div>
      )}

      {/* About Section */}
      {/* Information about the garden centre */}
      <div className="about-section">
        <h3>About Us</h3>
        <p>
          We're passionate about helping you grow your dream garden. From native plants to eco-friendly tools, we've got everything you need to thrive.
        </p>
      </div>
    </main>
  );
}

export default Home;
