// Currency Selector Component
// L00172671
// Oisin Gibson

/* 
 * REFERENCES 
 * - getBoundingClientRect(): https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect
 * - addEventListener(): https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener
 * - window.innerWidth: https://developer.mozilla.org/en-US/docs/Web/API/Window/innerWidth
 */

import React, { useState, useEffect, useRef } from 'react';
import { useCurrency } from '../context/CurrencyContext';
import './CurrencySelector.css';

const CurrencySelector = () => {// Arrow function to define CurrencySelector component
  const { selectedCurrency, currencies, changeCurrency, currentCurrency } = useCurrency();
  
  // useState: Manages dropdown open/close state
  // Returns [stateValue, setterFunction] - isOpen tracks if dropdown is visible
  const [isOpen, setIsOpen] = useState(false);
  
  // useState
  // Stores top, left, right positions to prevent dropdown from going off-screen
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, right: 0 });
  
  // useRef: Creates mutable reference to dropdown DOM element
  // Doesn't trigger re-renders when changed, persists across renders
  // Used for click-outside detection and dropdown positioning
  const dropdownRef = useRef(null);
  
  // useRef: Creates mutable reference to toggle button DOM element  
  // Used to calculate dropdown position relative to button
  const buttonRef = useRef(null);

  // Calculate dropdown position when opening to prevent overflow
  const handleToggle = () => {// Arrow function to handle dropdown toggle
    // Only calculate position when opening dropdown (not closing)
    // buttonRef.current ensures the button element exists in DOM
    if (!isOpen && buttonRef.current) {
      // getBoundingClientRect() returns element's size and position relative to viewport
      // Provides: top, bottom, left, right, width, height coordinates
      const rect = buttonRef.current.getBoundingClientRect();
      const dropdownWidth = 220; // Approximate dropdown width in pixels
      const viewportWidth = window.innerWidth; // Current browser window width
      
      // Calculate optimal horizontal position for dropdown
      let leftPos = rect.left; // Default: align dropdown left edge with button left edge
      let rightPos = null; // Alternative: distance from right edge of viewport
      
      // Collision detection: check if dropdown would extend beyond right edge of viewport
      // rect.left + dropdownWidth > viewportWidth - 20 means dropdown needs 20px padding from edge
      if (rect.left + dropdownWidth > viewportWidth - 20) {
        // Position dropdown to align with right edge of button instead
        rightPos = viewportWidth - rect.right; // Distance from viewport right edge
        leftPos = null; // Clear left positioning
      }
      
      // Final collision check: if still off-screen, force position within viewport bounds
      if (leftPos !== null && leftPos + dropdownWidth > viewportWidth - 20) {
        leftPos = viewportWidth - dropdownWidth - 20; // Force position with 20px margin
        rightPos = null; // Clear right positioning
      }
      
      // Update dropdown position state with calculated coordinates
      // top: position dropdown just below button (rect.bottom + 4px gap)
      setDropdownPosition({
        top: rect.bottom + 4, // 4px gap between button and dropdown
        left: leftPos, // Calculated left position or null
        right: rightPos // Calculated right position or null
      });
    }
    // Toggle dropdown open/close state (true becomes false, false becomes true)
    setIsOpen(!isOpen);
  };

  // useEffect: Set up click-outside detection to auto-close dropdown
  // Runs after component mounts and when dependencies change
  // Empty dependency array [] means this only runs once after initial render
  useEffect(() => {
    // Event handler function to detect clicks outside dropdown
    const handleClickOutside = (event) => {
      // Check if dropdown element exists AND click target is not inside dropdown
      // dropdownRef.current.contains() returns true if click is inside dropdown
      // !contains() means click is outside dropdown
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false); // Close dropdown when clicking outside
      }
    };

    // Add event listener to entire document to catch all clicks
    // 'mousedown' fires before 'click', providing better UX
    document.addEventListener('mousedown', handleClickOutside);
    
    // Cleanup function: removes event listener when component unmounts
    // Prevents memory leaks and event listener accumulation
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []); // Empty dependency array: effect only runs once after mount

  // Handle currency selection and close dropdown
  const handleCurrencyChange = (currencyCode) => {
    changeCurrency(currencyCode); // Update selected currency in context
    setIsOpen(false); // Close dropdown after selection
  };

  return (
    // Main container div with ref for click-outside detection
    <div className="currency-selector" ref={dropdownRef}>
      {/* Toggle button that shows current currency and opens/closes dropdown */}
      <button 
        ref={buttonRef} // Reference for position calculations
        className="currency-toggle"
        onClick={handleToggle} // Toggle dropdown on click
        aria-label="Select currency" // Accessibility label for screen readers
        aria-expanded={isOpen} // Accessibility: tells screen readers if dropdown is open
      >
        {/* Current currency display */}
        <span className="currency-display">
          <span className="currency-symbol">{currentCurrency.symbol}</span>
          <span className="currency-code">{selectedCurrency}</span>
        </span>
        {/* Dropdown arrow icon that rotates when open */}
        <svg 
          className={`dropdown-arrow ${isOpen ? 'open' : ''}`} // CSS class changes based on open state
          width="12" 
          height="12" 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="2"
        >
          <polyline points="6,9 12,15 18,9"></polyline>
        </svg>
      </button>

      {/* 
       * CONDITIONAL RENDERING EXPLANATION:
       * React conditional rendering using logical AND operator (&&)
       * If isOpen is true: renders the JSX after &&
       * If isOpen is false: renders nothing (null)
       * More efficient than ternary for show/hide because no "else" case needed
       */}
      {isOpen && (
        <div 
          className="currency-dropdown"
          style={{
            /* 
             * POSITION: FIXED EXPLANATION:
             * position: 'fixed' positions element relative to browser viewport
             * Unlike 'absolute' (relative to parent), 'fixed' ignores scroll position
             * Element stays in exact viewport coordinates even when page scrolls
             * Perfect for dropdowns that need to stay visible above all content
             */
            position: 'fixed',
            
            /* 
             * DYNAMIC TOP POSITIONING:
             * Template literal ${} embeds JavaScript expression in string
             * dropdownPosition.top is calculated pixel value from button bottom
             * 'px' converts number to valid CSS unit
             */
            top: `${dropdownPosition.top}px`,
            
            /* 
             * CONDITIONAL LEFT POSITIONING:
             * Ternary operator: condition ? valueIfTrue : valueIfFalse
             * If dropdownPosition.left is NOT null: use calculated pixel position
             * If dropdownPosition.left IS null: use 'auto' (browser calculates)
             */
            left: dropdownPosition.left !== null ? `${dropdownPosition.left}px` : 'auto',
            
            /* 
             * CONDITIONAL RIGHT POSITIONING:
             * Mirror of left positioning logic
             * Used when dropdown would overflow viewport right edge
             * Sets distance from RIGHT edge of viewport instead of left
             */
            right: dropdownPosition.right !== null ? `${dropdownPosition.right}px` : 'auto',
            
            /* 
             * Z-INDEX STACKING EXPLANATION:
             * z-index controls stacking order of positioned elements
             * Higher numbers appear above lower numbers
             * 10001 is very high to ensure dropdown appears above:
             * - Modal overlays (usually 1000-9999)
             * - Fixed headers/navbars (usually 100-999)
             * - Regular page content (usually 1-99 or auto)
             */
            zIndex: 10001
          }}
        >
          <div className="currency-list">
            {/* 
             * OBJECT.ENTRIES() AND ARRAY MAPPING:
             * Object.entries(currencies) converts:
             * { USD: {symbol: '$', name: 'US Dollar'} }
             * TO: [['USD', {symbol: '$', name: 'US Dollar'}]]
             * 
             * .map() creates new array by transforming each element
             * ([code, currency]) is array destructuring:
             * - code = 'USD', 'EUR', 'GBP' (the key)
             * - currency = {symbol: '$', name: 'US Dollar'} (the value)
             */}
            {Object.entries(currencies).map(([code, currency]) => (
              <button
                /* 
                 * REACT KEY PROP:
                 * key={code} provides unique identifier for each list item
                 * Required by React for efficient re-rendering
                 * Helps React track which items changed/added/remove
                 */
                key={code}
                
                /* 
                 * CONDITIONAL CSS CLASS:
                 * Template literal with embedded conditional logic
                 * Base class: 'currency-option' (always applied)
                 * Conditional class: 'selected' (only when code matches selectedCurrency)
                 * Result: "currency-option" or "currency-option selected"
                 * CSS can then style .selected differently (highlight, different color, etc.)
                 */
                className={`currency-option ${code === selectedCurrency ? 'selected' : ''}`}
                
                /* 
                 * EVENT HANDLER WITH CLOSURE:
                 * () => handleCurrencyChange(code) creates arrow function
                 * Captures 'code' variable from current loop iteration
                 * When clicked, calls handleCurrencyChange with specific currency code
                 * Arrow function needed to pass parameter to event handler
                 */
                onClick={() => handleCurrencyChange(code)}
              >
                <span className="currency-info">
                  <span className="currency-symbol-option">{currency.symbol}</span>
                  <span className="currency-details">
                    <span className="currency-code-option">{code}</span>
                    <span className="currency-name">{currency.name}</span>
                  </span>
                </span>
                {/* 
                 * CONDITIONAL ICON RENDERING:
                 * Shows checkmark SVG only for currently selected currency
                 * Same conditional rendering pattern as main dropdown
                 * Provides visual feedback for current selection
                 * SVG viewBox="0 0 24 24" defines coordinate system
                 * polyline points draw checkmark shape
                 */}
                {code === selectedCurrency && (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="20,6 9,17 4,12"></polyline>
                  </svg>
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CurrencySelector;
