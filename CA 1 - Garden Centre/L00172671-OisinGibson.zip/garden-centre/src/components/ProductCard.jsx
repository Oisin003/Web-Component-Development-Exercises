// Oisin Gibson
// L00172671
// src/components/ProductCard.jsx
// Reusable product card component for displaying garden centre items with sustainability metrics

/* 
 * REFERENCES & DOCUMENTATION:
 * 
 * React Component Design:
 * - Component Props: https://react.dev/learn/passing-props-to-a-component
 * - Conditional Rendering: https://react.dev/learn/conditional-rendering
 * - Event Handling: https://react.dev/learn/responding-to-events

 * 
 * JavaScript Concepts:
 * - Optional Chaining: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Optional_chaining
 * - Nullish Coalescing: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Nullish_coalescing
 * - Array.find(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/find
 * - Array.some(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/some
 */

// Import React hooks
import React, { useContext, useState } from "react";

// Import the basket context to access shared basket functions and data
import { useBasket } from "../context/BasketContext";

// Import the currency context for price formatting
import { useCurrency } from "../context/CurrencyContext";

// Import styles specific to the product card
import "../ProductCard.css";

// Define the ProductCard component + receive product details as props
// This component accepts multiple ways to receive product data for flexibility:
// 1. item object (complete product) - preferred method
// 2. individual props (id, name, price, images) - legacy support
// 3. placeholderMessage - for error states
export default function ProductCard({ item, id, name, price, images, placeholderMessage }) {
  // Flexible product data handling - use item if provided, otherwise construct from individual props
  // Optional chaining (?.) safely accesses properties that might be undefined
  const product = item || (id ? { id, name, price, images } : null);

  // Access basket-related functions and data from context
  // Custom hook provides: addToBasket, removeFromBasket, basketItems array
  const { addToBasket, removeFromBasket, basketItems } = useBasket();

  // Access currency formatting functions
  const { formatPrice } = useCurrency();

  // Initialize "added" state from basket state if product exists
  // useState with function initialization - only runs once on component mount
  // Boolean() ensures we get true/false rather than truthy/falsy values
  // Array.some() checks if any basket item matches this product's ID
  const [added, setAdded] = useState(() =>// arrow function to initialize added state
    Boolean(product && basketItems?.some((b) => b.id === product.id))
  );

  // State to track if item was just added (for visual feedback)
  const [justAdded, setJustAdded] = useState(false);

  // Early return pattern - guard clause to prevent rendering errors
  // If there's no product data, render a placeholder card with helpful message
  if (!product) {
    return (
      <div className="product-card placeholder">
        <div className="product-image placeholder-image" />
        <div className="product-info">
          <h3>{placeholderMessage || "Item not found"}</h3>
        </div>
      </div>
    );
  }
  
  // Image source selection with fallback chain
  // 1. Try first image from images array
  // 2. Try single image property 
  // 3. Fall back to empty string (will trigger placeholder)
  const imgSrc = product.images?.[0] || product.image || "";

  // Calculate quantity by counting how many times this product appears in basket
  // Array.filter() creates new array with all matching items
  // .length gives us the count of matching items
  const quantity = basketItems?.filter((b) => b.id === product.id).length || 0;

  // Debug logging to see what's happening
  console.log('Product ID:', product.id, 'Quantity:', quantity, 'BasketItems:', basketItems);

  // Event handler for adding product to basket
  // Calls the addToBasket function from BasketContext with current product
  const handleAdd = () => {
    addToBasket(product);
    // Set temporary "just added" state for visual feedback
    setJustAdded(true);
    // Clear the indicator after 2 seconds
    setTimeout(() => setJustAdded(false), 2000);
  };

  // Event handler for removing product from basket
  // Calls the removeFromBasket function from BasketContext with current product
  const handleRemove = () => {// Arrow function for handleRemove
    removeFromBasket(product);
  };

  // Get sustainability color based on eco score
  // Color coding system for visual feedback on environmental impact
  // Returns hex color codes for different score ranges
  const getSustainabilityColor = (score) => {
    if (score >= 90) return '#22c55e'; // Green - Excellent environmental impact
    if (score >= 75) return '#84cc16'; // Light green - Good environmental impact
    if (score >= 60) return '#f59e0b'; // Orange - Fair environmental impact
    return '#ef4444'; // Red - Poor environmental impact
  };

  // Get sustainability label based on numeric score
  // Converts numeric eco score to human-readable text labels
  const getSustainabilityLabel = (score) => {// Arrow function for getSustainabilityLabel
    if (score >= 90) return 'Excellent';
    if (score >= 75) return 'Good';
    if (score >= 60) return 'Fair';
    return 'Poor';
  };

  // Render the product card UI
  // JSX return statement that defines the component's visual structure
  return (// Main return statement for the component
    <div className="product-card">
      {/* Product Image Section with Error Handling */}
      {imgSrc ? (// Conditional rendering: if imgSrc exists, render the image
        <img
          src={imgSrc}
          alt={product.name}// Accessibility: descriptive alt text for screen readers
          onError={(e) => {// Error handler for failed image loads
            console.warn("Image failed to load:", imgSrc);// Log warning for debugging
            e.currentTarget.onerror = null;// Prevent infinite error loops
            e.currentTarget.src = "/images/placeholder.png";// Set fallback image
          }}
        />
        // : means else
      ) : (// Else: render a placeholder div if no image source
        <div className="product-image placeholder-image" />
      )}

      {/* Product Content Section */}
      <div className="content">
        {/* Product Name */}
        <h3>{product.name}</h3>
        
        {/* Sustainability Score Display */}
        {/* Conditional rendering - only show sustainability info if data exists */}
        {product.sustainability && (
          <div className="sustainability-info">
            {/* Eco Score Badge with dynamic color coding */}
            <div className="eco-score">
              <span 
                className="score-badge"
                style={{ 
                  backgroundColor: getSustainabilityColor(product.sustainability.ecoScore),
                  color: 'white',
                  padding: '4px 8px',
                  borderRadius: '12px',
                  fontSize: '12px',
                  fontWeight: 'bold'
                }}
              >
                {/* Plant/Leaf icon using Bootstrap Icons SVG */}
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" viewBox="0 0 16 16" style={{ marginRight: '4px' }}>
                  <path d="M4.158 12.025a.5.5 0 0 1-.638-.062A2.5 2.5 0 0 1 2.5 9.5v-6a.5.5 0 0 1 .5-.5h1.5a.5.5 0 0 1 .5.5v6a1.5 1.5 0 0 0 1.5 1.5.5.5 0 0 1 0 1c-.916 0-1.699-.663-1.892-1.525"/>
                  <path d="M9.5 13a1.5 1.5 0 0 1-1.5-1.5v-6A2.5 2.5 0 0 1 10.5 3h1A2.5 2.5 0 0 1 14 5.5a.5.5 0 0 1-1 0A1.5 1.5 0 0 0 11.5 4h-1A1.5 1.5 0 0 0 9 5.5v6a.5.5 0 0 0 .5.5.5.5 0 0 1 0 1z"/>
                </svg>
                {product.sustainability.ecoScore}/100
              </span>
              {/* Textual label for eco score rating */}
              <span className="score-label" style={{ fontSize: '11px', color: '#666', marginLeft: '5px' }}>
                {getSustainabilityLabel(product.sustainability.ecoScore)}
              </span>
            </div>
            
            {/* Detailed sustainability metrics */}
            <div className="sustainability-details" style={{ fontSize: '10px', color: '#888', marginTop: '4px' }}>
              {/* Water usage indicator with droplet icon */}
              <span>
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" fill="currentColor" viewBox="0 0 16 16" style={{ marginRight: '2px' }}>
                  <path fillRule="evenodd" d="M7.21.8C7.69.295 8 0 8 0q.164.544.371 1.038c.812 1.946 2.073 3.35 3.197 4.6C12.878 7.096 14 8.345 14 10a6 6 0 0 1-12 0C2 6.668 5.58 2.517 7.21.8m.413 1.021A31 31 0 0 0 5.794 3.99c-.726.95-1.436 2.008-1.96 3.07C3.304 8.133 3 9.138 3 10a5 5 0 0 0 10 0c0-1.201-.796-2.157-2.181-3.7l-.03-.032C9.75 5.11 8.5 3.72 7.623 1.82z"/>
                </svg>
                {product.sustainability.waterUsage}
              </span>
              {/* Carbon footprint with globe icon */}
              <span style={{ marginLeft: '8px' }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" fill="currentColor" viewBox="0 0 16 16" style={{ marginRight: '2px' }}>
                  <path d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m7.5-6.923c-.67.204-1.335.82-1.887 1.855A8 8 0 0 0 5.145 4H7.5zM4.09 4a9.3 9.3 0 0 1 .64-1.539 7 7 0 0 1 .597-.933A7.03 7.03 0 0 0 2.255 4zm-.582 3.5c.03-.877.138-1.718.312-2.5H1.674a7 7 0 0 0-.656 2.5zM4.847 5a12.5 12.5 0 0 0-.338 2.5H7.5V5zM8.5 5v2.5h2.99a12.5 12.5 0 0 0-.337-2.5zM4.51 8.5a12.5 12.5 0 0 0 .337 2.5H7.5V8.5zm3.99 0V11h2.653c.187-.765.306-1.608.338-2.5zM5.145 12q.208.58.468 1.068c.552 1.035 1.218 1.65 1.887 1.855V12zm.182 2.472a7 7 0 0 1-.597-.933A9.3 9.3 0 0 1 4.09 12H2.255a7.03 7.03 0 0 0 3.072 2.472M3.82 11a13.7 13.7 0 0 1-.312-2.5h-2.49c.062.89.291 1.733.656 2.5zm6.853 3.472A7.03 7.03 0 0 0 13.745 12H11.91a9.3 9.3 0 0 1-.64 1.539 7 7 0 0 1-.597.933M8.5 12v2.923c.67-.204 1.335-.82 1.887-1.855q.26-.487.468-1.068zm3.68-1h2.146c.365-.767.594-1.61.656-2.5h-2.49a13.7 13.7 0 0 1-.312 2.5m2.802-3.5a7 7 0 0 0-.656-2.5H12.18c.174.782.282 1.623.312 2.5zM11.27 2.461c.247.464.462.98.64 1.539h1.835a7.03 7.03 0 0 0-3.072-2.472c.218.284.418.598.597.933M10.855 4a8 8 0 0 0-.468-1.068C9.835 1.897 9.17 1.282 8.5 1.077V4z"/>
                </svg>
                {product.sustainability.carbonFootprint}kg CO2
              </span>
              
              {/* Show special badges for organic/recycled/biodegradable products */}
              {/* Conditional rendering of certification badges based on product properties */}
              <div style={{ marginTop: '3px' }}>
                {/* Organic certification badge */}
                {product.sustainability.organic && (
                  <span style={{ 
                    backgroundColor: '#22c55e', 
                    color: 'white', 
                    padding: '2px 6px', 
                    borderRadius: '8px', 
                    fontSize: '9px',
                    marginRight: '4px'
                  }}>
                    ORGANIC
                  </span>
                )}
                {/* Biodegradable certification badge */}
                {product.sustainability.biodegradable && (// Conditional rendering for biodegradable badge
                  <span style={{ 
                    backgroundColor: '#84cc16', 
                    color: 'white', 
                    padding: '2px 6px', 
                    borderRadius: '8px', 
                    fontSize: '9px',
                    marginRight: '4px'
                  }}>
                    BIO
                  </span>
                )}
                {/* Recycled material percentage badge */}
                {product.sustainability.recycledMaterial && (
                  <span style={{ 
                    backgroundColor: '#0ea5e9', 
                    color: 'white', 
                    padding: '2px 6px', 
                    borderRadius: '8px', 
                    fontSize: '9px'
                  }}>
                    {product.sustainability.recycledMaterial}% RECYCLED
                  </span>
                )}
              </div>
            </div>
          </div>
        )}
        
        {/* Price Display Section */}
        <div className="meta">
          {/* Price formatting with currency conversion and currency symbol */}
          {/* Nullish coalescing (??) defaults to 0 if price is undefined/null */}
          {/* formatPrice handles currency conversion and formatting */}
          <p>{formatPrice(product.price ?? 0)}</p>
        </div>
        
        {/* Action Buttons Section */}
        <div className="action-buttons">
          {/* Add to Basket Button */}
          <button className="cardButton" onClick={handleAdd}>
            Add
          </button>
          
          {/* Added to Cart Indicator - shows when item is in basket */}
          {quantity > 0 && (
            <div className="cart-indicator" style={{backgroundColor: 'lightgreen', padding: '5px', margin: '5px'}}>
              <span className="cart-status">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M9 11l3 3L22 4"></path>
                  <circle cx="9" cy="21" r="1"></circle>
                  <circle cx="20" cy="21" r="1"></circle>
                  <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                </svg>
                Added to cart
                {/* Quantity badge - only show if more than 1 */}
                {quantity > 1 && (
                  <span className="quantity-badge">
                    x{quantity}
                  </span>
                )}
              </span>
              
              {/* Just Added Animation - shows briefly when item is added */}
              {justAdded && (
                <span className="just-added-indicator" style={{backgroundColor: 'red', color: 'white', padding: '2px'}}>
                  ✓ Added!
                </span>
              )}
            </div>
          )}
          
          {/* Conditional rendering: only show remove button if item is in basket */}
          {quantity > 0 && (
            <button className="cardButton remove-button" onClick={handleRemove}>
              Remove
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
