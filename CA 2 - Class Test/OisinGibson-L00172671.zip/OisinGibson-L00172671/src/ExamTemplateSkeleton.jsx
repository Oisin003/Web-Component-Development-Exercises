
import { useEffect, useState } from "react";

export default function ExamTemplateSkeleton() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {

    fetch("/contacts.json")
      .then((res) => {
        if (!res.ok) {
          throw new Error("Failed to load data (status " + res.status + ")");
        }
        return res.json();
      })
      .then((data) => {
        setItems(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p style={{ color: "red" }}>Error: {error}</p>;

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          
          {item.name} Age {item.age} Friends {item.friends}
        </li>
      ))}
    </ul>
  );
}